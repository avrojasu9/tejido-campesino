# Publicación inicial y posterior copia al GitHub institucional

## Objetivo

Mantener **una copia en `avrojasu9/tejido-campesino`** y, cuando exista el GitHub institucional autorizado por ACIT, copiar el contenido e historial sin perder el respaldo personal. No se debe utilizar la función **Transfer ownership** si la intención es conservar ambos repositorios como copias: el traslado mueve el repositorio original a otro propietario.

## Paso 1. Crear el repositorio en la cuenta personal

1. Abrir https://github.com/new con la sesión de la cuenta `avrojasu9`.
2. Owner: `avrojasu9`; Repository name: `tejido-campesino`.
3. Seleccionar **Public** si ACIT autoriza la difusión del contenido; si todavía requiere revisión institucional, seleccionar **Private**.
4. Crear el repositorio **vacío**, sin `README`, `LICENSE` ni `.gitignore` automáticos, para evitar conflictos al subir el paquete.
5. Subir todos los archivos de este paquete conservando las carpetas `assets/` y `docs/`.

**Alternativa:** después de crear el repositorio vacío, compartir la URL en la conversación y solicitar a ChatGPT que publique los archivos mediante la conexión de GitHub, siempre que el conector tenga permisos.

## Paso 2. Publicar la página con GitHub Pages (opcional)

- Ir a `Settings` → `Pages`.
- En `Build and deployment`, seleccionar `Deploy from a branch`.
- Elegir rama `main`, carpeta `/ (root)` y `Save`.
- La URL prevista, una vez desplegada, es `https://avrojasu9.github.io/tejido-campesino/` (solo funcionará después de activar Pages y verificar el despliegue).

## Paso 3. Copiar más adelante a otra cuenta u organización

Cuando se cree un repositorio vacío en la cuenta institucional y se tengan permisos, se puede mantener el historial de Git de las dos copias con:

```bash
# Clonar el repositorio personal conservando ramas y etiquetas.
git clone --mirror https://github.com/avrojasu9/tejido-campesino.git
cd tejido-campesino.git

# En destino, reemplazar ORGANIZACION por el owner autorizado.
git push --mirror https://github.com/ORGANIZACION/tejido-campesino.git
```

**Precaución:** `git push --mirror` puede eliminar referencias en el destino que no estén en el origen. Usar únicamente contra el repositorio institucional vacío o uno cuya sustitución esté expresamente autorizada. Para colaboración habitual posterior, conviene configurar dos remotos y decidir cuál es fuente oficial.

Si lo que ACIT desea es **trasladar** el repositorio y no conservar copia separada, GitHub dispone de transferencia de propiedad; esa operación no deja automáticamente un repositorio independiente en la cuenta original.

## Paso 4. Actualizar referencias

Después de la copia, revisar links, GitHub Pages, políticas de licencia, visibilidad, responsables institucionales y declaraciones de IA. No publicar información adicional de ACIT sin su aprobación.
