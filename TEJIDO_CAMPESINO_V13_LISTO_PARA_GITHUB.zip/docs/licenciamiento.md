# Licenciamiento previsto

**Decisión pendiente de ACIT.** La página y el contenido técnico inicial de este repositorio son documentación preliminar de la propuesta, y la organización debe aprobar formalmente las condiciones de publicación y licencia.

## Criterios para el futuro software

1. Publicar el código fuente de la aplicación y sus pruebas bajo una **licencia libre reconocida**.
2. Comprobar la compatibilidad de licencias con el SDK, firmware, librerías y cualquier código reutilizado de Meshtastic.
3. Convenir por escrito derechos de autor, contribución y publicación con estudiantes y entidades académicas participantes.
4. Excluir secretos, datos personales y material institucional protegido de cualquier licencia de código.

Una opción a estudiar para módulos propios independientes es Apache-2.0, **sujeta a la compatibilidad técnica y jurídica de la integración real**. No se afirma que este repositorio o los futuros desarrollos ya hayan recibido esa licencia.
