# Créditos fotográficos — TEJIDO CAMPESINO

Las fotografías del sitio proceden de los registros documentales del visor **Dimensión Ambiental de la ZRC Montaña Caucana** y de los procesos campesinos representados allí.

**Fotografía y archivo territorial:** Angie Viviana Rojas Urueña.

**Fuente de consulta:** [Repositorio del visor ambiental](https://github.com/avrojasu9/dimension-ambiental-zrc-montana-caucana), carpeta `assets/images/`.

La presentación fotográfica acompaña el contexto campesino, territorial, ambiental y organizativo. **Ninguna fotografía corresponde a una prueba de funcionamiento de TEJIDO CAMPESINO o a un despliegue de la futura red LoRa.**

## Fotografías incorporadas

1. `04_juntanza_01_recorridos_y_conscientizacion_en_territorios_estrategicos_05.jpg` — paisaje de páramo de la Montaña Caucana (portada y galería).
2. `01_portada_zrc_montana_caucana.jpg` — actividad de siembra en el páramo (galería).
3. `04_juntanza_01_recorridos_y_conscientizacion_en_territorios_estrategicos_01.jpg` — recorrido comunitario (territorio y galería).
4. `05_agroalimentarias_semillas_cafe_tradicional.jpg` — semillas de café tradicional (galería).
5. `05_agroalimentarias_cultivo_tomate_el_descanso.jpg` — cultivo campesino en El Descanso (galería).
6. `04_juntanza_03_restauracion_nacimiento_de_agua_guanacas_01.jpg` — actividad de cuidado del agua (galería).
7. `07_acit_cierre.jpg` — encuentro de la ACIT (comunidad y galería).

Las fotografías se mantienen referenciadas desde el repositorio de origen; no se modifican los originales.

## Photo credits (English)

Photos by **Angie Viviana Rojas Urueña**, from the [Montaña Caucana environmental viewer repository](https://github.com/avrojasu9/dimension-ambiental-zrc-montana-caucana). The images document territorial, environmental and community processes. **They do not show TEJIDO CAMPESINO software or LoRa deployments.**
