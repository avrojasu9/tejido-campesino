# Colaboración y aportes

**Estado:** repositorio informativo en etapa de formulación. No hay aún una convocatoria pública de voluntariado, pasantías o contratación.

TEJIDO CAMPESINO espera publicar código libre reutilizable una vez exista desarrollo y autorización institucional. La propuesta contempla equipos remunerados y pasantías formales; abrir un repositorio no sustituye compromisos académicos o contractuales.

## Formas potenciales de contribuir en el futuro

- Revisar documentación técnica y reproducibilidad de pruebas con datos sintéticos.
- Contrastar decisiones de integración con Meshtastic y licencias de dependencias.
- Evaluar medidas de accesibilidad de la interfaz Android.
- Proponer mejoras de seguridad mediante divulgación responsable.

No subir conversaciones, actas internas, fotografías comunitarias ni datos de los territorios sin autorización expresa.
