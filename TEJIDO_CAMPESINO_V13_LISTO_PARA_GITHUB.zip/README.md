# TEJIDO CAMPESINO

![Logotipo de ACIT](assets/acit-logo.jpg)

**Comunicarnos, incluso cuando no hay señal.**

Una iniciativa de la **Asociación Campesina de Inzá Tierradentro (ACIT)**, Inzá, Cauca, Colombia, que articula organización comunitaria, tecnología abierta y comunicación campesina.

En veredas con problemas intermitentes de acceso a internet, energía eléctrica o cobertura celular, se propone investigar y probar una herramienta para enviar avisos organizativos desde teléfonos Android conectados por Bluetooth a radios LoRa compatibles con Meshtastic. El alcance territorial se deberá medir; aún no existe una red comunitaria desplegada por este proyecto.

## Resultados que se propone desarrollar

1. **Aplicación Android abierta:** herramienta para preparar y compartir avisos comunitarios, cuyo diseño se definirá durante el proyecto.
2. **Comunicación autónoma LoRa:** configuración, ensayos y mediciones de enlace sin depender de internet comercial o redes celulares para el transporte por radio.
3. **Seguridad de la información:** modelo de amenazas, protección de dispositivos y datos, controles y procedimientos de respuesta.
4. **Software libre reutilizable:** código fuente, especificaciones, resultados de pruebas y documentación que otras organizaciones puedan adaptar.

La propuesta se apoyará en tecnologías abiertas existentes. El alcance técnico específico se definirá y verificará durante la investigación.

## La página pública

- `index.html`: sitio estático bilingüe, adaptable a computador y celular.
- `assets/styles.css`: presentación visual.
- `assets/app.js`: traducciones, diagrama de cinco pasos, cuatro hitos, galería y ventana fotográfica ampliable.
- `assets/acit-logo.jpg`: identificación gráfica institucional.
- `docs/`: información general del proyecto, seguridad, licenciamiento y transparencia sobre IA.

La página usa siete fotografías territoriales reales del [visor ambiental de la ZRC Montaña Caucana](https://github.com/avrojasu9/dimension-ambiental-zrc-montana-caucana), con crédito fotográfico de **Angie Viviana Rojas Urueña**. Las imágenes se muestran desde su repositorio original; por ello requieren acceso a internet. El código no contiene claves de API ni librerías externas.

Las fotografías muestran vida, territorios y procesos campesinos. **No son evidencia de una red LoRa implementada.**

## Equipo previsto

Coordinación técnica y dirección externa de pasantías, coordinación comunitaria ACIT, tres pasantías académicas remuneradas (Android, LoRa y seguridad), mentoría, revisión técnica de seguridad, actividades con Radio Campesina y participación de comunidades. Los acuerdos y vinculaciones se formalizarán por los mecanismos institucionales correspondientes.

## Documentación

- [Ruta de ocho meses](docs/hoja-de-ruta.md)
- [Seguridad y cuidado territorial](docs/seguridad.md)
- [Colaboración](docs/colaboracion.md)
- [Licenciamiento previsto](docs/licenciamiento.md)
- [Créditos fotográficos](docs/creditos-fotograficos.md)
- [Autoría comunitaria y transparencia sobre IA](docs/transparencia-ia.md)
- [Guía de migración a GitHub de ACIT](docs/migracion-github.md)

## Autoría comunitaria y transparencia sobre IA

**TEJIDO CAMPESINO nace de las necesidades, experiencias y propuestas de las personas que integran la Asociación Campesina de Inzá Tierradentro (ACIT).**

Durante la preparación se utilizaron herramientas de inteligencia artificial como apoyo para analizar información, organizar ideas, explorar alternativas y preparar materiales preliminares. Los propósitos y las decisiones organizativas corresponden a ACIT.

Consulta la [declaración completa](docs/transparencia-ia.md).

## Repositorio público

El código de este sitio se mantiene en [TEJIDO CAMPESINO](https://github.com/avrojasu9/tejido-campesino).

Para activar la página: en GitHub ir a **Settings → Pages → Build and deployment → Deploy from a branch → main → /(root)** y guardar. La web se publicará en `https://avrojasu9.github.io/tejido-campesino/` cuando GitHub confirme el despliegue.

Las fotografías territoriales se sirven desde el repositorio original de la dimensión ambiental de la ZRC Montaña Caucana. El repositorio del visor no se modifica.

La [guía de migración](docs/migracion-github.md) describe cómo copiar el proyecto al futuro GitHub institucional de ACIT conservando el respaldo personal.
