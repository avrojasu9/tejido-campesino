# Archivo fotográfico

Las siete fotografías territoriales que muestra esta versión se enlazan directamente desde los archivos del [visor ambiental de la ZRC Montaña Caucana](https://github.com/avrojasu9/dimension-ambiental-zrc-montana-caucana/tree/main/assets/images). No se incluyen copias binarias en esta carpeta.

Autora: **Angie Viviana Rojas Urueña**. Los créditos y la relación de fotografías se encuentran en `docs/creditos-fotograficos.md`.

El diseño usa carga diferida en la galería y formatos JPEG existentes. Para una distribución totalmente independiente del visor ambiental, exportar fotografías locales optimizadas, retirar metadatos EXIF cuando proceda y modificar los URL de `index.html` y `assets/app.js`.
